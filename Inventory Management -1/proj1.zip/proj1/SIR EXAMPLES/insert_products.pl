#!/usr/bin/perl

use DBI;

my $host = "opatija.sdsu.edu";
my $port = "3306";
my $database = "jadrn000";
my $username = "jadrn000";
my $password = "apple";
my $database_source = "dbi:mysql:$database:$host:$port";
	
my $dbh = DBI->connect($database_source, $username, $password) 
or die 'Cannot connect to db';

my $sku = 'RBX-997';
my $category = 'DSLR';
my $title = 'Pentax K1000';
my $cost = 347.75;
my $retail = 799.95;

my $statement = "INSERT INTO products VALUES(".
	"'$sku','$category','$title',$cost,$retail);";
	
print "The statement to execute is: $statement\n"; #debug	
$rows = $dbh->do($statement);
if($DBI::err) {
    print "Sorry, an error occurred: $DBI::errstr\n";
    }
else {    
    print "Success, the number of rows affected is $rows\n";	
	}
	
$dbh->disconnect();
