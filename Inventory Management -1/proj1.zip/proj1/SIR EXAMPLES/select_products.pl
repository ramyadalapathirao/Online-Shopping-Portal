#!/usr/bin/perl

use DBI;

my $host = "opatija.sdsu.edu";
my $port = "3306";
my $database = "jadrn000";
my $username = "jadrn000";
my $password = "apple";
my $database_source = "dbi:mysql:$database:$host:$port";
	
my $dbh = DBI->connect($database_source, $username, $password) 
or die 'Cannot connect to db';

my $sth = $dbh->prepare("SELECT sku, title, retail FROM products ORDER BY title");
$sth->execute();

print "\nSKU\t\tModel   \t\tRetail\n";
print "===\t\t=====   \t\t======\n";
while(@row =  $sth->fetchrow_array()) {
    foreach $item (@row) {
        print "$item\t\t";
        }
    print "\n";
    }

$sth->finish();
$dbh->disconnect();
